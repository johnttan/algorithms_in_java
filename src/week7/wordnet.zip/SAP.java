/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author johntan
 */
public class SAP {
    private Digraph graph;
    
    public SAP(Digraph G){
        graph = new Digraph(G);
    }
    
    public int length(int v, int w){
        return 0;
    }
    
    public int ancestor(int v, int w){
        return 0;
    }
    
    public int length(Iterable<Integer> v, Iterable<Integer> w){
        return 0;
    }
    
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w){
        return 0;
    }
    
    public static void main(String[] args){
        
    }
}
